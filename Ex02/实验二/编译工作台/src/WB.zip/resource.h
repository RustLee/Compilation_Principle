//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WB.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_GRMTYPE                     129
#define IDI_TYPE0                       130
#define IDI_TYPE1                       131
#define IDI_TYPE2                       132
#define IDI_TYPE3                       133
#define IDR_PROJECT_MENU                134
#define IDI_FOLDER_CLOSE                135
#define IDI_FOLDER_OPEN                 136
#define IDD_NEWPROJECT_DIALOG           137
#define IDD_NEW_DIALOG                  138
#define IDR_HTMTYPE                     139
#define IDR_AUTOTYPE                    141
#define IDR_SRCTYPE                     143
#define IDD_SELECT_DIALOG               145
#define IDD_GENERATE_DIALOG             147
#define IDR_AUTO_MENU                   148
#define IDR_PRJTYPE                     149
#define IDD_WIZARD_DIALOG               152
#define IDC_EDIT                        1000
#define IDC_INFO                        1001
#define IDC_DIRECTORY                   1002
#define IDC_LIST                        1003
#define IDC_DIRECTORY_BUTTON            1004
#define IDC_CHECK1                      1007
#define IDC_CHECK2                      1008
#define IDC_STATIC1                     1008
#define IDC_CHECK3                      1009
#define IDC_CHECK4                      1010
#define IDC_CHECK5                      1011
#define IDC_CHECK6                      1012
#define IDC_CHECK7                      1013
#define IDC_GRAMMAR_LIST                1015
#define IDC_SOURCE_LIST                 1016
#define IDC_SAMPLE_RADIO                1016
#define IDC_NEW_RADIO                   1017
#define IDC_OPEN_RADIO                  1018
#define IDC_NOP_RADIO                   1019
#define IDC_DISPLAY_CHECK               1020
#define ID_DELETE                       32771
#define ID_SAVE_ALL                     32772
#define ID_CLOSE_PROJECT                32773
#define ID_GENERATE                     32775
#define ID_AUTOTYPE0                    32776
#define ID_AUTOTYPE1                    32777
#define ID_AUTOTYPE2                    32778
#define ID_TOP                          32779
#define ID_CENTER                       32780
#define ID_BOTTOM                       32781
#define ID_PROJECT_TREE                 32782
#define ID_MESSAGE                      32783
#define ID_PARSE                        32784
#define ID_ADD_PROJECT                  32785
#define ID_COPY_IMAGE                   32786
#define ID_NAVIGATOR                    32789
#define ID_WIZARD                       32790

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        153
#define _APS_NEXT_COMMAND_VALUE         32791
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
